/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tiqah isza
 */
import java.sql.*;

public class UserDAO {
    
    //static Connection currentCon = null;
    //static ResultSet rs = null;
    
    public Boolean login(UserBean bean){
        
        // preparing some objects for connection
        Connection currentCon = null;
        ResultSet rs = null;
        Statement stmt;
        String searchQuery;
        String name = bean.getName();
        String password = bean.getPass();
        String userType = bean.getUserType();
        boolean valid = false;
        
        try {
            // connect to DB
            currentCon = ConnectionManager.getConnection();
            stmt = currentCon.createStatement();
            
                if(userType.equals("Pengurus")) {
                    searchQuery = "SELECT * FROM ADMINISTRATOR";
                    //searchQuery = "SELECT * FROM ADMINISTRATOR WHERE ADMINNAME='" + name + "' AND ADMINPASSWORD='" + password + "'";
                    rs = stmt.executeQuery(searchQuery);
                    while(rs.next())
                    {
                        String userName = rs.getString("ADMINNAME");
                        String userPass = rs.getString("ADMINPASSWORD");
                        
                        if(name.equals(userName)&& password.equals(userPass))
                        {
                            valid = true;
                        }
                    } 
                }
                if(userType.equals("Pengajar")) {
                    searchQuery = "SELECT * FROM COACH";
                    //searchQuery = "SELECT * FROM COACH WHERE COACHNAME='" + name + "' AND COACHPASSWORD='" + password + "'";
                    rs = stmt.executeQuery(searchQuery);
                    while(rs.next())
                    {
                        String userName = rs.getString("COACHNAME");
                        String userPass = rs.getString("COACHPASSWORD");
                        
                        if(name.equals(userName)&& password.equals(userPass))
                        {
                            valid = true;
                        }
                    }
                }
                if(userType.equals("Peserta")) {
                    searchQuery = "SELECT * FROM PARTICIPANT";
                    //searchQuery = "SELECT * FROM PARTICIPANT WHERE USERNAME='" + name + "' AND USERPASSWORD='" + password + "'";
                    rs = stmt.executeQuery(searchQuery);
                    while(rs.next())
                    {
                        String userName = rs.getString("USERNAME");
                        String userPass = rs.getString("USERPASSWORD");
                        
                        if(name.equals(userName)&& password.equals(userPass))
                        {
                            valid = true;
                        }
                    } 
                }
                else{   
                        valid = false;
                }
        }
        catch(Exception e){
                System.out.println("Log In Failed: An exception has occured! " + e);
                e.printStackTrace();
        }
        // some exception handling
        finally {
            if (rs != null) {
                try{                   
                    rs.close();
                }catch(Exception e){
                    stmt = null;
                }
            }
            if (currentCon != null) {
                try{
                    currentCon.close();
                }catch(Exception e){
                    
                }
                currentCon = null;
            }
        }
        return valid;
    }
    
    public String saveUser(UserBean bean){
        
        Connection con;
        PreparedStatement statement;
        //ResultSet resultSet;
        
        try
        {
            String fullName = bean.getFullName();
            String userName = bean.getName();
            String password = bean.getPass();
            String ic = bean.getIC();
            String email = bean.getEmail();
            String phoneNo = bean.getPhoneNo();
            String address = bean.getAddress();
            String type = bean.getUserType();
            con = ConnectionManager.getConnection();
            
            if(type.equalsIgnoreCase("Pengajar")){
                statement = con.prepareStatement("INSERT INTO COACH(COACHFULLNAME,COACHNAME, COACHPASSWORD,COACHIC, COACHEMAIL,COACHPHONENO, COACHADDRESS, USERTYPEID, USERTYPEDESC) VALUES( ?, ?, ?, ?, ?, ?, ?, 2 ,'PENGAJAR')");
                statement.setString(1, fullName); 
                statement.setString(2, userName); 
                statement.setString(3, password); 
                statement.setString(4, ic); 
                statement.setString(5, email); 
                statement.setString(6, phoneNo); 
                statement.setString(7, address); 
                
                //resultSet = statement.executeQuery("INSERT INTO COACH(COACHFULLNAME,COACHNAME, COACHPASSWORD,COACHIC, COACHEMAIL,COACHPHONENO, COACHADDRESS, USERTYPEID, USERTYPEDESC) VALUES('"+fullName+"','"+userName+"', '"+password+"','"+ic+"', '"+email+"', '"+phoneNo+"', '"+address+"', 2 ,'PENGAJAR')");
                int i = statement.executeUpdate();
                con.commit(); 
                String msg=" ";
                if(i!=0){  
                    msg="Record has been inserted";
                    System.out.println("<font size='6' color=blue>" + msg + "</font>"); 
                    return "SUCCESS";
                }  
                else{  
                    msg="Failed to insert the data";
                    System.out.println("<font size='6' color=blue>" + msg + "</font>");
                }
            }
            else if(type.equalsIgnoreCase("Peserta")){
                statement = con.prepareStatement("INSERT INTO PARTICIPANT(USERFULLNAME, USERNAME, USERPASSWORD, USERIC, USEREMAIL, USERPHONENO, USERADDRESS, USERTYPEID, USERTYPEDESC) VALUES( ?, ?, ?, ?, ?, ?, ?, 2 ,'PENGAJAR')");
                statement.setString(1, fullName); 
                statement.setString(2, userName); 
                statement.setString(3, password); 
                statement.setString(4, ic); 
                statement.setString(5, email); 
                statement.setString(6, phoneNo); 
                statement.setString(7, address); 
                
                //resultSet =  statement.executeQuery("INSERT INTO PARTICIPANT(USERFULLNAME, USERNAME, USERPASSWORD, USERIC, USEREMAIL, USERPHONENO, USERADDRESS, USERTYPEID, USERTYPEDESC) VALUES('"+fullName+"','"+userName+"', '"+password+"', '"+ic+"','"+email+"', '"+phoneNo+"', '"+address+"', 3 ,'PESERTA')");
                int i = statement.executeUpdate();
                con.commit(); 
                String msg=" ";
                if(i!=0){  
                    msg="Record has been inserted";
                    System.out.println("<font size='6' color=blue>" + msg + "</font>"); 
                    return "SUCCESS";
                }  
                else{  
                    msg="Failed to insert the data";
                    System.out.println("<font size='6' color=blue>" + msg + "</font>");
                }
            }
            
            
                
        }
        catch(SQLException e)
            {
                    e.printStackTrace();
            }
        return "Invalid";
    }
}
