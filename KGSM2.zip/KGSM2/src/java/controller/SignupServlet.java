/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.UserBean;
import model.UserDAO;

/**
 *
 * @author tiqah isza
 */
public class SignupServlet extends HttpServlet{
    
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)    
                        throws ServletException, java.io.IOException { 
                
        UserDAO signupDAO = new UserDAO();
        UserBean user = new UserBean();
        
        String psw = request.getParameter("psw");
        String psw2 = request.getParameter("psw2");
        
        if(psw.equals(psw2)){
            user.setPass(psw);
        }
        
        user.setFullName(request.getParameter("fname"));
        user.setName(request.getParameter("uname"));
        //user.setPass(request.getParameter("psw"));
        user.setIC(request.getParameter("noic"));
        user.setEmail(request.getParameter("email"));
        user.setPhoneNo(request.getParameter("phoneno"));
        user.setAddress(request.getParameter("address"));
        user.setUserType(request.getParameter("utype"));
        
        String saveUser = signupDAO.saveUser(user);
        
        if(saveUser.equals("SUCCESS"))
        {
            System.out.print("You Have Successfully SIGNED UP");
            request.getRequestDispatcher("index.jsp").forward(request,response);
        }
        else
        {
            request.setAttribute("errMessage",saveUser);
            //JOptionPane.showMessageDialog(null,"error password/username");
            //request.getRequestDispatcher("invalidLogin.jsp").forward(request,response);
            response.sendRedirect("index.jsp");
        }
    }
}
